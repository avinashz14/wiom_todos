from todos.libs.utils import Response


class Config:
    class GENERIC:
        SUCCESS = Response(0, "Success")
        FAILURE = Response(1, "Oops, Something went wrong!")
        FAILED = Response(2, "Failed")
        UNAVAILABLE = Response(2, "This feature is unavailable for sometime will get back soon")
        UNAUTHORIZED = Response(3, "Unauthorized")
        INVALID_ROLE = Response(4, "Invalid Role")
        PERMISSION_DENIED = Response(6, "Permission Denied")
        VERSION_BLOCKED = Response(8, "This version is blocked please Ask your supervisor for the latest APK")
        API_PAGE_LIMIT = Response(9, "API has limit of {} item per request")

    class DATA_MISSING:
        GENERAL_DATA_MISSING = [1001, "data missing"]
        TASK_ID_MISSING = [1002, "task id missing"]
        DESCRIPTION_MISSING = [1003, "description missing"]
        STATUS_MISSING = [1004, "status missing"]
        SUBTASK_ID_MISSING = [1005, "subtask id missing"]

        # _MISSING = [1002, "task id missing"]

    class ERRORS:
        SUBTASK_NOT_COMPLETED = Response(1, "all sub task not completed")
        NOT_FOUND = Response(2, "request data not found")

