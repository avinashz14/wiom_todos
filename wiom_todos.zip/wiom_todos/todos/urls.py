from django.urls import path

from todos.views.sub_task_view import SubTaskAPIView
from todos.views.task_view import TaskAPIView

urlpatterns = [
    path('/tasks', TaskAPIView.as_view(), name='task-create'),  # create
    path('/tasks/<int:task_id>', TaskAPIView.as_view(), name='task-get'),  # get, patch, update
    path('/tasks/<int:task_id>/status', TaskAPIView.as_view(), name='task-get'),  # get, patch, update status
    path('/tasks/<int:task_id>/subtasks', SubTaskAPIView.as_view(), name='create-sub_task'),  # create
    path('/tasks/<int:task_id>/subtasks/<int:sub_task_id>', SubTaskAPIView.as_view(), name='create-sub_task'),  # g, p, u
    path('/tasks/<int:task_id>/subtasks/<int:sub_task_id>/status', SubTaskAPIView.as_view(), name='create-sub_task'),
    # get, patch, update status
]
