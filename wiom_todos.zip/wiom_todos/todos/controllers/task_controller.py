from abc import ABC, abstractmethod

from todos.configs.configs import Config
from todos.db_managers.task_db_manager import TaskDB
from todos.models.task import TaskType, TaskStatus
from django.db import transaction


class TaskBaseController(ABC):

    def __init__(self, request_data: dict, payload_token: dict, headers={}):
        self.request_data = request_data
        self.request_headers = headers
        self.payload_token = payload_token
        self.result = None
        self.status = None
        self.message = None

    @abstractmethod
    def create_task(self):
        pass

    @abstractmethod
    def get_tasks(self, filters: dict):
        pass

    @abstractmethod
    def get_task_by_id(self, task_id: int):
        pass

    @abstractmethod
    def update_field(self, task_id: int, field_name: str, field_value):
        pass

    @abstractmethod
    def delete_task(self, task_id):
        pass

    @abstractmethod
    def update_task(self, task_id, updates):
        pass


class TaskController(TaskBaseController):

    def __init__(self, validated_data: dict, request_data: dict, payload_token: dict, headers={}):
        super(TaskController, self).__init__(request_data, payload_token, headers)
        self.validated_data = validated_data
        self.task_type = TaskType.TASK.value
        self.page = request_data.get('page', 0)
        self.limit = request_data.get('limit', (self.page + 1) * 10)

    def create_task(self):
        payload = {
            "description": self.validated_data["description"],
            "type": self.task_type,
            "status": TaskStatus.OPEN.value,
            "committed_by": self.payload_token.get("user_id")
        }
        self.status, self.message, self.result = TaskDB().create(payload)

    def get_tasks(self, filters: dict):
        self.status, self.message, self.result = TaskDB().list(**filters)

    def get_task_by_id(self, task_id: int):
        self.status, self.message, self.result = TaskDB().get_object_by_id(task_id)

    def delete_task(self, task_id):
        update = {
            "is_deleted": True,
        }
        self.update_field(task_id, **update)

    @transaction.atomic()
    def update_task(self, task_id, updates):
        for update in updates:
            self.update_field(task_id, **update)

    def update_field(self, task_id: int, field_name: str, field_value):
        self.status, self.message, task = TaskDB().get_object_by_id(task_id)
        if task is None:
            self.status, self.message = Config.ERRORS.NOT_FOUND.status, Config.ERRORS.NOT_FOUND.message
            return
        if field_name == "status" and field_value == TaskStatus.COMPLETED.value[1]:
            # all sub task to be done.
            filters = {
                "parent_id": task_id
            }
            self.status, self.message, self.result = TaskDB().list(**filters)
            if self.result is None:
                return
            else:
                for subtask in self.result:
                    if subtask is not TaskStatus.COMPLETED.value[0]:
                        self.status, self.message = Config.ERRORS.SUBTASK_NOT_COMPLETED.status, Config.ERRORS.SUBTASK_NOT_COMPLETED.message
                        return
        updates = {
            field_name: field_value,
            "committed_by": self.payload_token.get("user_id")
        }
        self.status, self.message, self.result = TaskDB().get_object_by_id(task_id, updates)


class SubTaskController(TaskBaseController):

    def __init__(self, task_id: int, validated_data: dict, request_data: dict, payload_token: dict, headers={}):
        super(SubTaskController, self).__init__(request_data, payload_token, headers)
        self.task_id = task_id
        self.validated_data = validated_data
        self.task_type = TaskType.SUBTASK.value

    def create_task(self):
        payload = {
            "parent_id": self.task_id,
            "description": self.validated_data["description"],
            "type": self.task_type,
            "status": TaskStatus.OPEN.value,
            "committed_by": self.payload_token.get("user_id")
        }
        self.status, self.message, self.result = TaskDB().create(payload)

    def get_tasks(self, filters: dict):
        filters.update(parent_id=self.task_id)
        # task_id required here.
        self.status, self.message, self.result = TaskDB().list(**filters)

    def get_task_by_id(self, task_id: int):
        self.status, self.message, self.result = TaskDB().get_object_by_id(task_id)

    def update_field(self, task_id: int, field_name: str, field_value):
        # state transition handle
        updates = {
            field_name: field_value,
            "committed_by": self.payload_token.get("user_id")
        }
        self.status, self.message, self.result = TaskDB().get_object_by_id(task_id, updates)

    def delete_task(self, task_id):
        update = {
            "is_deleted": True,
        }
        self.update_field(task_id, **update)

    @transaction.atomic()
    def update_task(self, task_id, updates):
        for update in updates:
            self.update_field(task_id, **update)
