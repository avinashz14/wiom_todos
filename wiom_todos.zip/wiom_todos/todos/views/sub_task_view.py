from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.conf import settings

from todos.configs.configs import Config
from todos.controllers.task_controller import TaskController, SubTaskController
from todos.serializers import task_serializer


class SubTaskAPIView(APIView):

    # @auth_object.user_authentication()
    def post(self, request, *args, **kwargs):

        s = task_serializer.SubTaskCreateSerializer(data=request)
        s.is_valid(raise_exception=True)
        payload_token = {}
        task_ctl = SubTaskController(validated_data=s.validated_data, request_data=request.data,
                                  payload_token=payload_token, headers=request.headers)
        task_ctl.create_task()
        if task_ctl.status != Config.GENERIC.SUCCESS.status:
            response = {"status": task_ctl.status, "message": task_ctl.message}
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        else:
            data = task_serializer.TaskSerializer(data=task_ctl.result)
            response = {"status": Config.GENERIC.SUCCESS.status, "message": Config.GENERIC.SUCCESS.message,
                        "data": data}
            return Response(response, status=status.HTTP_200_OK)

    # @auth_object.user_authentication()
    def get(self, request, *args, **kwargs):
        s = task_serializer.SubTaskQuerySerializer(data=request)
        s.is_valid(raise_exception=True)

        payload_token = {}
        task_ctl = SubTaskController(validated_data=s.validated_data, request_data=request.data,
                                  payload_token=payload_token, headers=request.headers)
        filters = {
            **s.validated_data
        }
        task_ctl.get_tasks(filters)
        if task_ctl.status != Config.GENERIC.SUCCESS.status:
            response = {"status": task_ctl.status, "message": task_ctl.message}
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        else:
            data = task_serializer.TaskSerializer(data=task_ctl.result)
            response = {"status": Config.GENERIC.SUCCESS.status, "message": Config.GENERIC.SUCCESS.message,
                        "data": data}
            return Response(response, status=status.HTTP_200_OK)

    # @auth_object.user_authentication()
    def patch(self, request, *args, **kwargs):

        s = task_serializer.SubTaskPatchSerializer(data=request.data)
        s.is_valid(raise_exception=True)

        payload_token = {}
        task_ctl = SubTaskController(validated_data=s.validated_data, request_data=request.data,
                                  payload_token=payload_token, headers=request.headers)

        sub_task_id = request.query.get("sub_task_id")
        task_ctl.update_field(sub_task_id, **s.validated_data)
        if task_ctl.status != Config.GENERIC.SUCCESS.status:
            response = {"status": task_ctl.status, "message": task_ctl.message}
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        else:
            data = task_serializer.TaskSerializer(data=task_ctl.result)
            response = {"status": Config.GENERIC.SUCCESS.status, "message": Config.GENERIC.SUCCESS.message,
                        "data": data}
            return Response(response, status=status.HTTP_200_OK)

    # @auth_object.user_authentication()
    def put(self, request, *args, **kwargs):

        s = task_serializer.SubTaskSerializer(data=request.data)
        s.is_valid(raise_exception=True)

        payload_token = {}
        task_ctl = SubTaskController(validated_data=s.validated_data, request_data=request.data,
                                  payload_token=payload_token, headers=request.headers)
        task_id = request.query.get("task_id")
        task_ctl.update_task(task_id, **s.validated_data)
        if task_ctl.status != Config.GENERIC.SUCCESS.status:
            response = {"status": task_ctl.status, "message": task_ctl.message}
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        else:
            data = task_serializer.TaskSerializer(data=task_ctl.result)
            response = {"status": Config.GENERIC.SUCCESS.status, "message": Config.GENERIC.SUCCESS.message,
                        "data": data}
            return Response(response, status=status.HTTP_200_OK)

    # @auth_object.user_authentication()
    def delete(self, request, *args, **kwargs):

        s = task_serializer.SubTaskSerializer(data=request.data)
        s.is_valid(raise_exception=True)

        payload_token = {}
        task_ctl = SubTaskController(validated_data=s.validated_data, request_data=request.data,
                                  payload_token=payload_token, headers=request.headers)
        sub_task_id = request.query.get("sub_task_id")
        task_ctl.delete_task(sub_task_id)
        if task_ctl.status != Config.GENERIC.SUCCESS.status:
            response = {"status": task_ctl.status, "message": task_ctl.message}
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        else:
            data = task_serializer.TaskSerializer(data=task_ctl.result)
            response = {"status": Config.GENERIC.SUCCESS.status, "message": Config.GENERIC.SUCCESS.message,
                        "data": data}
            return Response(response, status=status.HTTP_200_OK)
