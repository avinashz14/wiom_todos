from django.db import models


class BaseModel(models.Model):
    id = models.BigIntegerField(null=False, primary_key=True)
    active = models.BooleanField(default=1)
    is_deleted = models.BigIntegerField(default=0)
    created = models.DateTimeField(auto_now=True)
    updated = models.DateTimeField(auto_now_add=True)
