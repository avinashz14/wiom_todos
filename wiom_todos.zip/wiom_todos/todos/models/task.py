from django.db import models
import enum

from todos.models import BaseModel


# Create your models here.
class TaskType(models.IntegerChoices):
    TASK = 1, "Task"
    SUBTASK = 2, "Subtask"


class TaskStatus(models.IntegerChoices):
    OPEN = 1, "Open"
    IN_PROGRESS = 2, "In Progress"
    COMPLETED = 3, "Completed"


# Define Model
class Task(models.Model):
    description = models.CharField(max_length=255)
    type = models.SmallIntegerField(choices=TaskType.choices)
    status = models.SmallIntegerField(choices=TaskStatus.choices)
    committed_by = models.BigIntegerField()
    parent_id = models.BigIntegerField(null=True, blank=True)

    class Meta:
        db_table = "task"
