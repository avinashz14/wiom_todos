from rest_framework import serializers

from todos.configs.configs import Config
from todos.models.task import Task


class TaskSerializer(serializers.ModelSerializer):
    class Meta:
        model = Task
        fields = '__all__'


class TaskCreateSerializer(serializers.Serializer):
    def to_internal_value(self, request):
        data = request.data

        response = dict()
        if not data:
            response["status"], response["message"] = Config.DATA_MISSING.GENERAL_DATA_MISSING
            raise serializers.ValidationError(response)

        required_fields = {
            "description": {
                "type": str,
                "err": Config.DATA_MISSING.DESCRIPTION_MISSING
            }
        }
        for required_field, meta_data in required_fields:
            if data.get("required_field") is None or not isinstance(data.get("required_field"), meta_data["type"]):
                response["status"], response["message"] = meta_data["err"]
                raise serializers.ValidationError(response)

        return data


class TaskQuerySerializer(serializers.Serializer):
    def to_internal_value(self, request):
        data = request.data
        return data


class TaskPatchSerializer(serializers.Serializer):
    def to_internal_value(self, request):
        data = request.data
        response = dict()
        if not data:
            response["status"], response["message"] = Config.DATA_MISSING.GENERAL_DATA_MISSING
            raise serializers.ValidationError(response)

        query_params = request.query or {}
        task_id = query_params.get("task_id")
        if task_id is None:
            response["status"], response["message"] = Config.DATA_MISSING.TASK_ID_MISSING
            raise serializers.ValidationError(response)

        return data


class TaskUpdateSerializer(serializers.Serializer):
    def to_internal_value(self, request):
        data = request.data
        response = dict()
        if not data:
            response["status"], response["message"] = Config.DATA_MISSING.GENERAL_DATA_MISSING
            raise serializers.ValidationError(response)

        query_params = request.query or {}
        task_id = query_params.get("task_id")
        if task_id is None:
            response["status"], response["message"] = Config.DATA_MISSING.TASK_ID_MISSING
            raise serializers.ValidationError(response)

        return data


class SubTaskCreateSerializer(serializers.Serializer):
    def to_internal_value(self, request):
        data = request.data
        response = dict()
        if not data:
            response["status"], response["message"] = Config.DATA_MISSING.GENERAL_DATA_MISSING
            raise serializers.ValidationError(response)

        required_fields = {
            "task_id": {
                "type": int,
                "err": Config.DATA_MISSING.TASK_ID_MISSING
            },
            "description": {
                "type": str,
                "err": Config.DATA_MISSING.DESCRIPTION_MISSING
            }
        }
        for required_field, meta_data in required_fields:
            if data.get("required_field") is None or not isinstance(data.get("required_field"), meta_data["type"]):
                response["status"], response["message"] = meta_data["err"]
                raise serializers.ValidationError(response)

        return data


class SubTaskQuerySerializer(serializers.Serializer):
    def to_internal_value(self, request):
        data = request.data
        return data


class SubTaskPatchSerializer(serializers.Serializer):
    def to_internal_value(self, request):
        data = request.data
        response = dict()
        if not data:
            response["status"], response["message"] = Config.DATA_MISSING.GENERAL_DATA_MISSING
            raise serializers.ValidationError(response)

        query_params = request.query or {}
        task_id = query_params.get("task_id")
        if task_id is None:
            response["status"], response["message"] = Config.DATA_MISSING.TASK_ID_MISSING
            raise serializers.ValidationError(response)

        subtask_id = query_params.get("sub_task_id")
        if subtask_id is None:
            response["status"], response["message"] = Config.DATA_MISSING.SUBTASK_ID_MISSING
            raise serializers.ValidationError(response)

        return data


class SubTaskUpdateSerializer(serializers.Serializer):
    def to_internal_value(self, request):
        data = request.data
        response = dict()
        if not data:
            response["status"], response["message"] = Config.DATA_MISSING.GENERAL_DATA_MISSING
            raise serializers.ValidationError(response)

        query_params = request.query or {}
        task_id = query_params.get("task_id")
        if task_id is None:
            response["status"], response["message"] = Config.DATA_MISSING.TASK_ID_MISSING
            raise serializers.ValidationError(response)

        subtask_id = query_params.get("sub_task_id")
        if subtask_id is None:
            response["status"], response["message"] = Config.DATA_MISSING.SUBTASK_ID_MISSING
            raise serializers.ValidationError(response)

        return data
