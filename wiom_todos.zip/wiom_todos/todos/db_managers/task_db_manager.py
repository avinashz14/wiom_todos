from todos.configs.configs import Config
from todos.db_managers.base_manager import BaseDBManager
from todos.models.task import Task


class TaskDB(BaseDBManager):
    model = Task
    has_active_filter = False

    def create(self, payload: dict):

        try:
            user_device_config_info = Task.objects.create(**payload)
            return Config.GENERIC.SUCCESS.status, Config.GENERIC.SUCCESS.message, user_device_config_info

        except Exception as e:
            return Config.GENERIC.FAILURE.status, Config.GENERIC.FAILURE.message, None

    def list(self, **filters):
        qset = Task.objects.filter(**filters)
        return qset

    def get_by_id(self, obj_id):
        qset = self.get_object_by_id(obj_id=object)
        return qset
