from functools import wraps
from rest_framework.response import Response
from rest_framework import status
from rest_framework_simplejwt.authentication import JWTAuthentication
from django.contrib.auth.models import AnonymousUser


def user_authentication(view_func):

    @wraps(view_func)
    def wrapped_view(request, *args, **kwargs):
        auth = JWTAuthentication()
        user, token = auth.authenticate(request) or (None, None)

        if user is None or isinstance(user, AnonymousUser):
            return Response({"error": "Unauthorized access"}, status=status.HTTP_401_UNAUTHORIZED)

        request.user = user  # Set authenticated user
        return view_func(request, *args, **kwargs)

    return wrapped_view
